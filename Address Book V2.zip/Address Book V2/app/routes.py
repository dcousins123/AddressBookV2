from flask import render_template, request, flash, redirect
from app import app, db
from app.forms import contactDetails, editcontact, importCSVFile
from app.models import contact
from pandas import pandas as pd

#route / is used for the home page
@app.route('/')
def main():
    form = contactDetails()
    return render_template('index.html', form=form)

#route /contacts is used to display all contacts
@app.route('/contacts')
def contacts():
    Contacts = contact.query.all()
    return render_template('contacts.html', title='Contacts', rows=Contacts)

#route /addcontact is used to add a new contact to the db
@app.route('/addcontact', methods=['POST'])
def addcontact():
    form = contactDetails()
    firstname = request.form['firstname']
    surname = request.form['surname']
    address = request.form['address']
    phone = request.form['phone']
    email = request.form['email']
    if form.validate_on_submit():
        Contact = contact(firstname=str(firstname), surname=str(surname), address=str(address), phone=int(phone), email=str(email))
        form.populate_obj(Contact)
        db.session.add(Contact)
        db.session.commit()
        flash('Congratulations, you have added a contact!')
        return redirect('/contacts')
    return render_template('index.html', title='Home', form=form)

#route /editcontact/ followed by contID is used to identify and edit particular contact record in db
@app.route('/editcontact/<contID>', methods=['GET', 'POST'])
def editContact(contID):
    selectedContact = contact.query.filter_by(contID=contID).first()
    form = editcontact()
    if form.validate_on_submit():
        selectedContact.firstname = form.firstname.data
        selectedContact.surname = form.surname.data
        selectedContact.address = form.address.data
        selectedContact.phone = form.phone.data
        selectedContact.email = form.email.data
        db.session.commit()
        flash('Congratulations, you have edited a contact!')
        return redirect('/contacts')
    elif request.method == 'GET':
        form.contID.data = selectedContact.contID
        form.firstname.data = selectedContact.firstname
        form.surname.data = selectedContact.surname
        form.address.data = selectedContact.address
        form.phone.data = selectedContact.phone
        form.email.data = selectedContact.email
    return render_template('editcontact.html', title='Edit Contact', form=form)

#route /deletecontact/ followed by contID is used to delete a contact from edit page
@app.route('/deletecontact/<contID>', methods=['GET'])
def deletecontact(contID):
    selectedContact = contact.query.filter_by(contID=contID).first()
    db.session.delete(selectedContact)
    db.session.commit()
    flash('Congratulations, you have deleted a contact!')
    return redirect('/contacts')

#route /import is used to import a csv file
@app.route('/import', methods=['GET', 'POST'])
def importCon():
    form = importCSVFile()
    if form.validate_on_submit():
        df = pd.read_csv(request.files.get('fileChoice'))
        df.to_sql('contact', con=db.get_engine(), if_exists='append', index=False)
        flash('Congratulations, you have imported contact info!')
        return render_template('import.html', importContDisp=df.to_html(), form=form)
    return render_template('import.html', form=form)