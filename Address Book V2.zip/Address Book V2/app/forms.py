from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, SubmitField, FileField
from wtforms.validators import DataRequired

class contactDetails(FlaskForm):
    firstname = StringField('First Name: ', validators=[DataRequired(message="Check field. No special chars.")])
    surname = StringField('Surname: ', validators=[DataRequired(message="Check field. No special chars.")])
    address = StringField('Address: ', validators=[DataRequired(message="Check field. No special chars.")])
    phone = IntegerField('Phone: ', validators=[DataRequired(message="Check field. Numerical chars.")])
    email = StringField('Email: ', validators=[DataRequired(message="Check field. Ensure email valid.")])
    submit = SubmitField('Add')

class editcontact(FlaskForm):
    contID = StringField('Contact ID: ', validators=[])
    firstname = StringField('First Name: ', validators=[DataRequired(message="Check field. No special chars.")])
    surname = StringField('Surname: ', validators=[DataRequired(message="Check field. No special chars.")])
    address = StringField('Address: ', validators=[DataRequired(message="Check field. No special chars.")])
    phone = IntegerField('Phone: ', validators=[DataRequired(message="Check field. Numerical chars.")])
    email = StringField('Email: ', validators=[DataRequired(message="Check field. Ensure email valid.")])
    submit = SubmitField('Update')

class importCSVFile(FlaskForm):
    fileChoice = FileField('CSV File: ', validators=[DataRequired(message="Please upload a valid CSV file.")])
    submit = SubmitField('Upload')