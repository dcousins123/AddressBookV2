from app import db
from datetime import datetime

class contact(db.Model):
    contID = db.Column(db.Integer, primary_key=True)
    firstname = db.Column(db.String(32), nullable=False)
    surname = db.Column(db.String(32), nullable=False)
    address = db.Column(db.String(128), nullable=False)
    phone = db.Column(db.Integer, nullable=False)
    email = db.Column(db.String(64), nullable=False)

    def __repr__(self):
        return '<Contact {}>'.format(self.contID)